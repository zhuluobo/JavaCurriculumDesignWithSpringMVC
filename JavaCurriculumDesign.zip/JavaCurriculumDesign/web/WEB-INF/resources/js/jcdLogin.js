window.onload = initAll;

function initAll(){

}

