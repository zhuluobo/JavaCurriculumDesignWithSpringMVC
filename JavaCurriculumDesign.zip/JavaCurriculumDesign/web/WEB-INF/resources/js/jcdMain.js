window.onload = initAll;

//-- months、positions、colors、types、times
var months = ['Jan','Feb','Mar','Apr','May','June','July','Aug','Sept','Oct','Nov','Dec'];
var posX = ['35%','56.1%','77.1%'];
var posY = ['1%','33%','65%'];
var colors = ['#25c6fc','#ff534d','#fee388'];
var types = ['学习','工作','娱乐'];
var times = ['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30'];

function initAll(){
    $('#coverLayer').fadeOut('slow','swing');
    $('#timeNow').hover(function(){
        $('#coverLayer2').css('background-color','white');
        $('#coverLayer2').css('opacity','0.2');
    },function(){
        $('#coverLayer2').css('background-color','transparent');
        $('#coverLayer2').css('opacity','unset');

    });
    $('#addNewStuff,#stuffAmt').hover(function(){
        $(this).css('text-shadow', '0 0 4px');
    },function(){
        $(this).css('text-shadow', '0 0 0');
    });
    getStuff();
}

//-- 更新时间
window.setInterval(function(){
    var date = new Date();
    var day = date.getDate();
    var month = date.getMonth();
    var year = date.getFullYear();
    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();
    $('#second').text(second<10?('0'+second.toString()):second.toString());
    $('#minute').text(minute<10?('0'+minute.toString()):minute.toString());
    $('#hour').text(hour<10?('0'+hour.toString()):hour.toString());
    $('#year').text(year<10?('0'+year.toString()):year.toString());
    $('#month').text(months[month]);
    $('#day').text(day<10?('0'+day.toString()):day.toString());
},100);

//-- 新建一个待办
function createNewStuff(x,y,color,stuff,time){
    var newSpan = document.createElement('span');
    newSpan.innerHTML = '&times';
    newSpan.style.cursor = 'pointer';
    newSpan.style.color = 'white';
    newSpan.style.fontSize = '25px';
    newSpan.style.paddingLeft = '10px';
    newSpan.onclick = toDeleteOne;
    var newStuff = document.createElement('h2');
    newStuff.innerText = stuff;
    newStuff.style.paddingLeft = '35px';
    newStuff.style.fontFamily = '\'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif';
    newStuff.style.fontWeight = 'lighter';
    newStuff.style.letterSpacing = '5px';
    newStuff.style.paddingTop = '15px';
    var newTime = document.createElement('span');
    newTime.innerText = time;
    newTime.style.paddingLeft = '35px';
    newTime.style.fontFamily = '\'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif';
    newTime.style.fontWeight = 'lighter';
    newTime.style.fontSize = '30px';
    newTime.style.letterSpacing = '5px';
    var newDiv = document.createElement('div');
    newDiv.style.height = '30%';
    newDiv.style.width = '20%';
    newDiv.style.backgroundColor = colors[color];
    newDiv.style.position = 'fixed';
    newDiv.style.left = posX[x];
    newDiv.style.top = posY[y];
    newDiv.style.opacity = '0.6';
    $(newDiv).append(newSpan);
    $(newDiv).append(newStuff);
    $(newDiv).append(newTime);
    $(newDiv).hover(function(){
        $(this).css('opacity','0.8');
        $(this).css('box-shadow','0 0 4px #fff');
    },function(){
        $(this).css('opacity','0.6');
        $(this).css('box-shadow','unset');
    });
    $('body').append(newDiv);
}

//-- 删除一个事项
function toDeleteOne(){
    var stuffName = $(this).parent().children('h2').text();
    var data = {'stuffName':stuffName};
    $.ajax({
        url:'/deleteStuff',
        data:data,
        type:'POST',
        dataType:'json',
        success:function(res){
            if(res['ok']=='yep'){
                $('#alertBox').className = 'alert alert-danger alert-dismissible col-lg-2 col-lg-offset-1';
                $('#msg').text('删除成功。');
                $('#alertBox').slideDown('fast','linear');
                $('#alertBox').fadeOut('slow','linear');
                var wait = setInterval(function () {
                    if(!$('#alertBox').is(':animated'))window.location.reload();
                },50);
            }
        }
    });
}
function addNewStuff(){
    var date = new Date();
    var stuff = $('#whatStuff').val();
    var type = types[parseInt($('#selectType').val())];
    var time = date.getFullYear()+'-'+(parseInt(date.getMonth())+1).toString()+'-'+date.getDate()+' '+times[parseInt($('#selectTime').val())]+':00';

    var data = {'stuff':stuff,'type':type,'time':time};

    $.ajax({
        url:'/createStuff',
        type:'POST',
        data:data,
        dataType:'json',
        success:function(res){
            if(res['ok']=='yep'){
                $('#alertBox').className = 'alert alert-success alert-dismissible col-lg-2 col-lg-offset-1';
                $('#msg').text('新建成功。');
                $('#alertBox').slideDown('fast','linear');
                $('#alertBox').fadeOut('slow','linear');
                var wait = setInterval(function () {
                    if(!$('#alertBox').is(':animated')){
                        clearInterval(wait);
                        window.location.reload();
                    }
                },50);
            }
        }
    });
}

function menuToShow(){
    $('#addMenu').show();
}

//-- x:180,470 y:240,460
window.onclick = function(e){
    if((e.clientX<=180||e.clientX>=470||e.clientY<=240||e.clientY>=500)&&$('#addMenu').css('display')=='block'&&e.clientX!=0){
        $('#addMenu').hide();
    }
}

//-- 获取待办
function getStuff(){
    $.ajax({
        url:'/getStuff',
        type:'POST',
        dataType:'json',
        success:function(res){
            if(res['stuffs']){
                //-- 获取成功
                var stuffName = res['stuffs'].split(';');
                var stuffTime = res['times'].split(';');
                var stuffType = res['types'].split(';');
                $('#amtDisplay').text(stuffName.length);
                for(var i in stuffName)createNewStuff((stuffName.length-i-1)%3,Math.floor((stuffName.length-i-1)/3),stuffType[i]=='学习'?0:(stuffType[i]=='工作'?1:2),stuffName[i],stuffTime[i]);
            }
        }
    });
}