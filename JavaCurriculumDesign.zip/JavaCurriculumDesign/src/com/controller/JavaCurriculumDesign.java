package com.controller;

import java.sql.*;
import java.time.LocalDate;

import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
public class JavaCurriculumDesign {
    @RequestMapping("/")
    public String loginPage(){
        return "login";
    }

    @RequestMapping("/login")
    public String login(String act, String pwd){
        String url = "jdbc:mysql://localhost:3306/javacurriculumdesign?user=root&password=123456&useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC";
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        //-- 注册连接驱动
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }
        try{
            conn = DriverManager.getConnection(url);
        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        try{
            String sql = "SELECT pwd FROM login where id = "+act;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            boolean isCorrect = false;

            while(rs.next()){
                String pwdGet = rs.getString("pwd");
                if(pwdGet.equals(pwd))isCorrect = true;
            }

            if(isCorrect)return "mainPage";
            else return "login";

        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        return "login";
    }

    //-- 获取待办
    @ResponseBody
    @RequestMapping(value="/getStuff",produces = "application/json;charset=UTF-8")
    public String giveStuff(){
        String url = "jdbc:mysql://localhost:3306/javacurriculumdesign?user=root&password=123456&useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC";
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;

        //-- 获取的结果
        String resStuff = "";
        String resTime = "";
        String resType = "";

        //-- 注册连接驱动
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }

        try{
            conn = DriverManager.getConnection(url);
        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        try{
            String sql = "SELECT * FROM stuffs order by time desc limit 9";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            LocalDate localDate = LocalDate.now();

            while(rs.next()){
                String stuffGet = rs.getString("name");
                String timeGet = rs.getString("time");
                String typeGet = rs.getString("type");

                if(!timeGet.substring(0, 10).equals(localDate.toString()))break;

                resStuff += resStuff.equals("")?stuffGet:";"+stuffGet;
                resTime += resTime.equals("")?timeGet.substring(11,16):";"+timeGet.substring(11,16);
                resType += resType.equals("")?typeGet:";"+typeGet;
            }

        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        JSONObject res = new JSONObject();
        res.put("stuffs",resStuff);
        res.put("times",resTime);
        res.put("types",resType);

        return res.toString();
    }

    //-- 新建待办
    @ResponseBody
    @RequestMapping(value="/createStuff",produces = "application/json;charset=UTF-8")
    public String createStuff(String stuff,String time,String type){
        String sql = "insert into stuffs values ('"+stuff+"','"+time+"','"+type+"')";
        String url = "jdbc:mysql://localhost:3306/javacurriculumdesign?user=root&password=123456&useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC";
        Statement stmt = null;
        Connection conn = null;

        //-- 注册连接驱动
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }

        try{
            conn = DriverManager.getConnection(url);
        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        try{
            stmt = conn.createStatement();
            stmt.execute(sql);
        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        JSONObject res = new JSONObject();
        res.put("ok","yep");
        return res.toString();
    }

    //-- 删除待办
    @ResponseBody
    @RequestMapping(value="/deleteStuff",produces = "application/json;")
    public String deleteStuff(String stuffName){
        String sql = "delete from stuffs  where name = '"+stuffName+"'";
        String url = "jdbc:mysql://localhost:3306/javacurriculumdesign?user=root&password=123456&useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC";
        Statement stmt = null;
        Connection conn = null;

        //-- 注册连接驱动
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }

        try{
            conn = DriverManager.getConnection(url);
        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        try{
            stmt = conn.createStatement();
            stmt.execute(sql);

        }catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        JSONObject res = new JSONObject();
        res.put("ok","yep");
        return res.toString();
    }
}
